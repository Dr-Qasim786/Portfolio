import React from 'react'

const experience = () => {
  return (
    <section className='experience_section' id='experience'>
        <h2 className="section__title">Experience</h2>
        <span className="section__subtitle">My Experience</span>
    </section>
  )
}

export default experience