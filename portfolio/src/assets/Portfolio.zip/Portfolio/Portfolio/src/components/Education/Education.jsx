import React from 'react'

const education = () => {
  return (
    <section className='education_section' id='education'>
        <h2 className="section__title">Education</h2>
        <span className="section__subtitle">My Education</span>
    </section>
  )
}

export default education