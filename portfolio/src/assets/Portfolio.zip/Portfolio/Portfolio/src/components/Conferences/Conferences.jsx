import React from 'react'

const conferences = () => {
  return (
    <section className='conferences_section' id='conferences'>
        <h2 className="section__title">Conferences</h2>
        <span className="section__subtitle">My conferences</span>
    </section>
  )
}

export default conferences