import React from 'react'

const workshops = () => {
  return (
    <section className='workshops_section' id='workshops'>
        <h2 className="section__title">Workshops  & Research Trainings</h2>
        <span className="section__subtitle">My workshops</span>
    </section>
  )
}

export default workshops