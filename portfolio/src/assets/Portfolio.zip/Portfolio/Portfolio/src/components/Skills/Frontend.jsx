import React from "react";

const Frontend = () => {
  return (
    <div className="skills__content">
      <h3 className="skills__title">Teaching</h3>

      <div className="skills__box">
        <div className="skills__group">
          <div className="skills__data">
            <i className="bx bxl-html5 skills__icon"></i>

            <div>
              <h3 className="skills__name">Econometrics</h3>
            </div>
          </div>
          <div className="skills__data">
            <i class="bx bxl-css3 skills__icon"></i>

            <div>
              <h3 className="skills__name">Applied Economics</h3>
            </div>
          </div>
          <div className="skills__data">
            <i class="bx bxl-nodejs skills__icon"></i>

            <div>
              <h3 className="skills__name">Research Methods</h3>
            </div>
          </div>
        </div>
        <div className="skills__group">
          <div className="skills__data">
            <i class="bx bxl-tailwind-css skills__icon"></i>

            <div>
              <h3 className="skills__name">Microeconomics</h3>
            </div>
          </div>
          <div className="skills__data">
            <i class="bx bxl-react skills__icon"></i>

            <div>
              <h3 className="skills__name">Macroeconomics</h3>
            </div>
          </div>
          <div className="skills__data">
            <i class="bx bxl-redux skills__icon"></i>

            <div>
              <h3 className="skills__name">New Institution Economics</h3>
            </div>
          </div>
          <div className="skills__data">
            <i class="bx bxl-redux skills__icon"></i>

            <div>
              <h3 className="skills__name">International Trade</h3>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Frontend;
