import React from 'react'

const Publications = () => {
  return (
    <section className='publications_section' id='publications'>
        <h2 className="section__title">Publications</h2>
        <span className="section__subtitle">My publications</span>
    </section>
  )
}

export default Publications