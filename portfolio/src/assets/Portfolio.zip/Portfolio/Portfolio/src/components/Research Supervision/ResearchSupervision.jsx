import React from 'react'

const ResearchSupervision = () => {
  return (
    <section className='research_section' id='research'>
        <h2 className="section__title">Research Supervision</h2>
        <span className="section__subtitle">My research</span>
    </section>
  )
}

export default ResearchSupervision