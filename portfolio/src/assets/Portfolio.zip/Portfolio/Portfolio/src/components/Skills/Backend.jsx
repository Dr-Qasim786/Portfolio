import React from "react";
import jwt from "../../assets/jwt-logo.png";
import mongoose from "../../assets/mongoose-logo.png";
import express from "../../assets/express.png";

const Backend = () => {
  return (
    <div className="skills__content">
      <h3 className="skills__title">Research</h3>

      <div className="skills__box">
        <div className="skills__group">
          <div className="skills__data">
            <i class="bx bxl-nodejs skills__icon"></i>

            <div>
              <h3 className="skills__name">HEC Approved PhD Supervisor</h3>
            </div>
          </div>
          <div className="skills__data">
            <img src={express} />

            <div>
              <h3 className="skills__name">Research Supervision at BS & MPhil Level</h3>
            </div>
          </div>
          <div className="skills__data">
            <i class="bx bxl-mongodb skills__icon"></i>

            <div>
              <h3 className="skills__name">Data Analysis</h3>
            </div>
          </div>
        </div>
        <div className="skills__group">
          <div className="skills__data">
            <img src={mongoose} className="mongoose" />

            <div>
              <h3 className="skills__name">SPSS</h3>
            </div>
          </div>
          <div className="skills__data">
            <img src={jwt} />

            <div>
              <h3 className="skills__name">EViews</h3>
            </div>
          </div>
          <div className="skills__data">
            <i class="bx bxl-firebase skills__icon"></i>

            <div>
              <h3 className="skills__name">STATA</h3>
            </div>
          </div>
          <div className="skills__data">
            <i class="bx bxl-firebase skills__icon"></i>

            <div>
              <h3 className="skills__name">EndNote</h3>
            </div>
          </div>
          <div className="skills__data">
            <i class="bx bxl-firebase skills__icon"></i>

            <div>
              <h3 className="skills__name">Python Jupyter Notebook</h3>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Backend;
